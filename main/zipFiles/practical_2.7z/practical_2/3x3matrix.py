import numpy as np

lists = [[3,6,7],[4,3,5],[7,4,9]]

convert =  np.array(lists)

print(f"Before np array :\n {lists}")
print(f"After np array :\n {convert}")