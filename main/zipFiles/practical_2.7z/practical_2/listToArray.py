import numpy as np

lists = [1,23,4,5,6,3,2,6,87]

print(lists)

Array = np.array(lists)

print(Array)